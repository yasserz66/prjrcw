import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Card, ListGroup } from 'react-bootstrap';

function DoctorList() {
    const [doctors, setDoctors] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [name, setName] = useState('');
    const [specialty, setSpecialty] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const [username, setUsername] = useState('');  // Nouveau champ
    const [password, setPassword] = useState('');  // Nouveau champ
    const [editMode, setEditMode] = useState(false);
    const [currentDoctor, setCurrentDoctor] = useState(null);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/doctors/")
            .then(response => response.json())
            .then(data => setDoctors(data))
            .catch(error => console.error('Error:', error));
        
        fetch("http://127.0.0.1:8000/departments/")
            .then(response => response.json())
            .then(data => setDepartments(data))
            .catch(error => console.error('Error:', error));
    }, []);

    const addDoctor = () => {
        fetch("http://127.0.0.1:8000/doctors/", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, specialty, department_id: departmentId, username, password }),  // Ajouter username et password ici
        })
        .then(() => {
            setName('');
            setSpecialty('');
            setDepartmentId('');
            setUsername('');  // Réinitialiser le champ username
            setPassword('');  // Réinitialiser le champ password
            refreshDoctors();
        })
        .catch(error => console.error('Error:', error));
    };

    const updateDoctor = () => {
        fetch(`http://127.0.0.1:8000/doctors/${currentDoctor._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, specialty, department_id: departmentId, username, password }),  // Ajouter username et password ici
        })
        .then(() => {
            setName('');
            setSpecialty('');
            setDepartmentId('');
            setUsername('');  // Réinitialiser le champ username
            setPassword('');  // Réinitialiser le champ password
            setEditMode(false);
            setCurrentDoctor(null);
            refreshDoctors();
        })
        .catch(error => console.error('Error:', error));
    };

    const deleteDoctor = (id) => {
        fetch(`http://127.0.0.1:8000/doctors/${id}`, {
            method: 'DELETE',
        })
        .then(() => {
            refreshDoctors();
        })
        .catch(error => console.error('Error:', error));
    };

    const refreshDoctors = () => {
        fetch("http://127.0.0.1:8000/doctors/")
            .then(response => response.json())
            .then(data => setDoctors(data))
            .catch(error => console.error('Error:', error));
    };

    const editDoctor = (doctor) => {
        setEditMode(true);
        setCurrentDoctor(doctor);
        setName(doctor.name);
        setSpecialty(doctor.specialty);
        setDepartmentId(doctor.department_id);
        setUsername(doctor.username);  // Charger le username existant pour la modification
        setPassword('');  // Ne pas charger le mot de passe existant pour des raisons de sécurité
    };

    return (
        <Container>
            <Row className="my-4">
                <Col>
                    <h2>Gestion des Médecins</h2>
                    <Card>
                        <Card.Body>
                            <Form>
                                <Form.Group controlId="formDoctorName">
                                    <Form.Label>Nom du médecin</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Nom du médecin" 
                                        value={name} 
                                        onChange={(e) => setName(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formSpecialty" className="mt-3">
                                    <Form.Label>Spécialité</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Spécialité" 
                                        value={specialty} 
                                        onChange={(e) => setSpecialty(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formUsername" className="mt-3">
                                    <Form.Label>Nom d'utilisateur</Form.Label>  {/* Nouveau champ pour le nom d'utilisateur */}
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Nom d'utilisateur" 
                                        value={username} 
                                        onChange={(e) => setUsername(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formPassword" className="mt-3">
                                    <Form.Label>Mot de passe</Form.Label>  {/* Nouveau champ pour le mot de passe */}
                                    <Form.Control 
                                        type="password" 
                                        placeholder="Mot de passe" 
                                        value={password} 
                                        onChange={(e) => setPassword(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formDepartment" className="mt-3">
                                    <Form.Label>Département</Form.Label>
                                    <Form.Control 
                                        as="select" 
                                        value={departmentId} 
                                        onChange={(e) => setDepartmentId(e.target.value)}
                                    >
                                        <option value="">Sélectionner un département</option>
                                        {departments.map(department => (
                                            <option key={department._id} value={department._id}>
                                                {department.name}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>

                                <Button 
                                    variant={editMode ? "warning" : "primary"} 
                                    className="mt-3"
                                    onClick={editMode ? updateDoctor : addDoctor}
                                >
                                    {editMode ? 'Modifier' : 'Ajouter'}
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <ListGroup>
                                {doctors.map(doctor => (
                                    <ListGroup.Item key={doctor._id} className="d-flex justify-content-between align-items-center">
                                        <div>
                                            {doctor.name} - {doctor.specialty} - Département: {departments.find(d => d._id === doctor.department_id)?.name}
                                        </div>
                                        <div>
                                            <Button 
                                                variant="warning" 
                                                size="sm" 
                                                className="me-2" 
                                                onClick={() => editDoctor(doctor)}
                                            >
                                                Modifier
                                            </Button>
                                            <Button 
                                                variant="danger" 
                                                size="sm" 
                                                onClick={() => deleteDoctor(doctor._id)}
                                            >
                                                Supprimer
                                            </Button>
                                        </div>
                                    </ListGroup.Item>
                                ))}
                            </ListGroup>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default DoctorList;
