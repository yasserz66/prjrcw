import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Card, Table, Alert } from 'react-bootstrap';

function Appointment() {
    const [patients, setPatients] = useState([]);
    const [doctors, setDoctors] = useState([]);
    const [appointments, setAppointments] = useState([]);
    const [selectedPatient, setSelectedPatient] = useState('');
    const [selectedDoctor, setSelectedDoctor] = useState('');
    const [appointmentDate, setAppointmentDate] = useState('');
    const [filterPatient, setFilterPatient] = useState('');
    const [filterDoctor, setFilterDoctor] = useState('');
    const [editMode, setEditMode] = useState(false);
    const [currentAppointmentId, setCurrentAppointmentId] = useState(null);
    const [alert, setAlert] = useState({ show: false, message: '', variant: '' });

    useEffect(() => {
        fetch("http://127.0.0.1:8000/patients/")
            .then(response => response.json())
            .then(data => setPatients(data))
            .catch(error => console.error('Error:', error));

        fetch("http://127.0.0.1:8000/doctors/")
            .then(response => response.json())
            .then(data => setDoctors(data))
            .catch(error => console.error('Error:', error));

        fetchAppointments();
    }, []);

    const fetchAppointments = () => {
        fetch("http://127.0.0.1:8000/appointments/")
            .then(response => response.json())
            .then(data => setAppointments(data))
            .catch(error => console.error('Error:', error));
    };

    const handleAppointment = () => {
        const appointment = {
            patient_id: selectedPatient,
            doctor_id: selectedDoctor,
            appointment_date: appointmentDate
        };

        const url = editMode ? `http://127.0.0.1:8000/appointments/${currentAppointmentId}` : "http://127.0.0.1:8000/appointments/";
        const method = editMode ? 'PUT' : 'POST';

        fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(appointment),
        })
        .then(response => response.json())
        .then(data => {
            setAlert({
                show: true,
                message: editMode ? "Rendez-vous modifié avec succès!" : "Rendez-vous pris avec succès!",
                variant: "success"
            });
            setEditMode(false);
            setCurrentAppointmentId(null);
            setSelectedPatient('');
            setSelectedDoctor('');
            setAppointmentDate('');
            fetchAppointments();
        })
        .catch(error => {
            setAlert({
                show: true,
                message: "Une erreur s'est produite, veuillez réessayer.",
                variant: "danger"
            });
            console.error('Error:', error);
        });
    };

    const editAppointment = (appointment) => {
        setEditMode(true);
        setCurrentAppointmentId(appointment._id);
        setSelectedPatient(appointment.patient_id);
        setSelectedDoctor(appointment.doctor_id);
        setAppointmentDate(appointment.appointment_date.slice(0, 16));
    };

    const deleteAppointment = (id) => {
        fetch(`http://127.0.0.1:8000/appointments/${id}`, {
            method: 'DELETE',
        })
        .then(() => {
            setAlert({
                show: true,
                message: "Rendez-vous supprimé avec succès!",
                variant: "warning"
            });
            fetchAppointments();
        })
        .catch(error => {
            setAlert({
                show: true,
                message: "Une erreur s'est produite, veuillez réessayer.",
                variant: "danger"
            });
            console.error('Error:', error);
        });
    };

    const filteredAppointments = appointments.filter(appointment => {
        return (filterPatient === '' || appointment.patient_id === filterPatient) &&
               (filterDoctor === '' || appointment.doctor_id === filterDoctor);
    });

    return (
        <Container>
            <Row className="my-4">
                <Col>
                    <h2>Prendre un Rendez-vous</h2>
                    {alert.show && <Alert variant={alert.variant} onClose={() => setAlert({ show: false })} dismissible>{alert.message}</Alert>}
                    <Card>
                        <Card.Body>
                            <Form>
                                <Form.Group controlId="formPatient">
                                    <Form.Label>Patient</Form.Label>
                                    <Form.Control as="select" value={selectedPatient} onChange={(e) => setSelectedPatient(e.target.value)}>
                                        <option value="">Sélectionner un patient</option>
                                        {patients.map(patient => (
                                            <option key={patient._id} value={patient._id}>
                                                {patient.name}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>

                                <Form.Group controlId="formDoctor" className="mt-3">
                                    <Form.Label>Médecin</Form.Label>
                                    <Form.Control as="select" value={selectedDoctor} onChange={(e) => setSelectedDoctor(e.target.value)}>
                                        <option value="">Sélectionner un médecin</option>
                                        {doctors.map(doctor => (
                                            <option key={doctor._id} value={doctor._id}>
                                                {doctor.name}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>

                                <Form.Group controlId="formAppointmentDate" className="mt-3">
                                    <Form.Label>Date du Rendez-vous</Form.Label>
                                    <Form.Control 
                                        type="datetime-local" 
                                        value={appointmentDate} 
                                        onChange={(e) => setAppointmentDate(e.target.value)}
                                    />
                                </Form.Group>

                                <Button 
                                    variant={editMode ? "warning" : "primary"} 
                                    className="mt-3"
                                    onClick={handleAppointment}
                                >
                                    {editMode ? 'Modifier le Rendez-vous' : 'Fixer le Rendez-vous'}
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <h2>Liste des Rendez-vous</h2>
                    <Card>
                        <Card.Body>
                            <Row>
                                <Col md={6}>
                                    <Form.Group controlId="filterPatient">
                                        <Form.Label>Filtrer par patient</Form.Label>
                                        <Form.Control as="select" value={filterPatient} onChange={(e) => setFilterPatient(e.target.value)}>
                                            <option value="">Tous les patients</option>
                                            {patients.map(patient => (
                                                <option key={patient._id} value={patient._id}>
                                                    {patient.name}
                                                </option>
                                            ))}
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                                <Col md={6}>
                                    <Form.Group controlId="filterDoctor">
                                        <Form.Label>Filtrer par médecin</Form.Label>
                                        <Form.Control as="select" value={filterDoctor} onChange={(e) => setFilterDoctor(e.target.value)}>
                                            <option value="">Tous les médecins</option>
                                            {doctors.map(doctor => (
                                                <option key={doctor._id} value={doctor._id}>
                                                    {doctor.name}
                                                </option>
                                            ))}
                                        </Form.Control>
                                    </Form.Group>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>Patient</th>
                                        <th>Médecin</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredAppointments.map(appointment => (
                                        <tr key={appointment._id}>
                                            <td>{patients.find(p => p._id === appointment.patient_id)?.name}</td>
                                            <td>{doctors.find(d => d._id === appointment.doctor_id)?.name}</td>
                                            <td>{new Date(appointment.appointment_date).toLocaleString()}</td>
                                            <td>
                                                <Button 
                                                    variant="warning" 
                                                    size="sm" 
                                                    className="me-2" 
                                                    onClick={() => editAppointment(appointment)}
                                                >
                                                    Modifier
                                                </Button>
                                                <Button 
                                                    variant="danger" 
                                                    size="sm" 
                                                    onClick={() => deleteAppointment(appointment._id)}
                                                >
                                                    Supprimer
                                                </Button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default Appointment;
