import React, { useState, useEffect } from 'react';
import { Container, Card, ListGroup } from 'react-bootstrap';

function ViewDoctors() {
    const [doctors, setDoctors] = useState([]);
    const [departments, setDepartments] = useState({});

    useEffect(() => {
        // Récupération des médecins
        fetch("http://127.0.0.1:8000/doctors/")
            .then(response => response.json())
            .then(data => setDoctors(data))
            .catch(error => console.error('Error:', error));

        // Récupération des départements
        fetch("http://127.0.0.1:8000/departments/")
            .then(response => response.json())
            .then(data => {
                const departmentMap = {};
                data.forEach(department => {
                    departmentMap[department._id] = department.name;
                });
                setDepartments(departmentMap);
            })
            .catch(error => console.error('Error:', error));
    }, []);

    return (
        <Container className="mt-4">
            <h2 className="mb-4">Liste des Médecins</h2>
            <ListGroup>
                {doctors.map(doctor => (
                    <ListGroup.Item key={doctor._id} className="mb-3">
                        <Card>
                            <Card.Body>
                                <Card.Title>{doctor.name}</Card.Title>
                                <Card.Text>
                                    <strong>Spécialité:</strong> {doctor.specialty} <br />
                                    <strong>Département:</strong> {departments[doctor.department_id] || 'N/A'}
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </ListGroup.Item>
                ))}
            </ListGroup>
        </Container>
    );
}

export default ViewDoctors;
