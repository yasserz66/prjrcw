import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Button, Form, Alert, Container, Row, Col } from 'react-bootstrap';

function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleLogin = async () => {
        try {
            const response = await fetch('http://localhost:8000/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (data.role) {
                localStorage.setItem('role', data.role);
                localStorage.setItem('userId', data.userId);

                if (data.role === 'admin') {
                    navigate('/');
                } else if (data.role === 'doctor') {
                    navigate('/');
                } else if (data.role === 'patient') {
                    navigate('/');
                }
            } else {
                setError('Nom d’utilisateur ou mot de passe incorrect');
            }
        } catch (err) {
            setError('Erreur de connexion');
        }
    };

    return (
        <Container className="d-flex justify-content-center align-items-center vh-100">
            <Row className="w-100">
                <Col md={{ span: 6, offset: 3 }}>
                    <Card className="shadow">
                        <Card.Body>
                            <h2 className="text-center mb-4">Connexion</h2>
                            {error && <Alert variant="danger">{error}</Alert>}
                            <Form>
                                <Form.Group className="mb-3" controlId="formBasicEmail">
                                    <Form.Label>Nom d'utilisateur</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Entrez votre nom d'utilisateur" 
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                    />
                                </Form.Group>

                                <Form.Group className="mb-3" controlId="formBasicPassword">
                                    <Form.Label>Mot de passe</Form.Label>
                                    <Form.Control 
                                        type="password" 
                                        placeholder="Entrez votre mot de passe" 
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                </Form.Group>

                                <Button 
                                    variant="primary" 
                                    type="button" 
                                    className="w-100"
                                    onClick={handleLogin}
                                >
                                    Se connecter
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default Login;
