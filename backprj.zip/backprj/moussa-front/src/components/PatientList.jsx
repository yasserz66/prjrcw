import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Card, ListGroup, Table } from 'react-bootstrap';

function PatientList() {
    const [patients, setPatients] = useState([]);
    const [doctors, setDoctors] = useState([]);
    const [name, setName] = useState('');
    const [birthdate, setBirthdate] = useState('');
    const [username, setUsername] = useState('');  // Nouveau champ
    const [password, setPassword] = useState('');  // Nouveau champ
    const [newDisease, setNewDisease] = useState('');
    const [diseaseDate, setDiseaseDate] = useState('');
    const [history, setHistory] = useState([]);
    const [doctorId, setDoctorId] = useState('');
    const [editMode, setEditMode] = useState(false);
    const [currentPatient, setCurrentPatient] = useState(null);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/patients/")
            .then(response => response.json())
            .then(data => setPatients(data))
            .catch(error => console.error('Error:', error));
        
        fetch("http://127.0.0.1:8000/doctors/")
            .then(response => response.json())
            .then(data => setDoctors(data))
            .catch(error => console.error('Error:', error));
    }, []);

    const addPatient = () => {
        fetch("http://127.0.0.1:8000/patients/", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, birthdate, history, doctor_id: doctorId, username, password }),  // Ajouter username et password ici
        })
        .then(() => {
            setName('');
            setBirthdate('');
            setUsername('');  // Réinitialiser le champ username
            setPassword('');  // Réinitialiser le champ password
            setHistory([]);
            setDoctorId('');
            refreshPatients();
        })
        .catch(error => console.error('Error:', error));
    };

    const updatePatient = () => {
        fetch(`http://127.0.0.1:8000/patients/${currentPatient._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, birthdate, history, doctor_id: doctorId, username, password }),  // Ajouter username et password ici
        })
        .then(() => {
            setName('');
            setBirthdate('');
            setUsername('');  // Réinitialiser le champ username
            setPassword('');  // Réinitialiser le champ password
            setHistory([]);
            setDoctorId('');
            setEditMode(false);
            setCurrentPatient(null);
            refreshPatients();
        })
        .catch(error => console.error('Error:', error));
    };

    const deletePatient = (id) => {
        fetch(`http://127.0.0.1:8000/patients/${id}`, {
            method: 'DELETE',
        })
        .then(() => {
            refreshPatients();
        })
        .catch(error => console.error('Error:', error));
    };

    const refreshPatients = () => {
        fetch("http://127.0.0.1:8000/patients/")
            .then(response => response.json())
            .then(data => setPatients(data))
            .catch(error => console.error('Error:', error));
    };

    const editPatient = (patient) => {
        setEditMode(true);
        setCurrentPatient(patient);
        setName(patient.name);
        setBirthdate(patient.birthdate);
        setUsername(patient.username);  // Charger le username existant pour la modification
        setPassword('');  // Ne pas charger le mot de passe existant pour des raisons de sécurité
        setHistory(Array.isArray(patient.history) ? patient.history : []);  // Assurez-vous que history est un tableau
        setDoctorId(patient.doctor_id);
    };

    const addDiseaseToHistory = () => {
        const newHistoryEntry = { disease: newDisease, date: diseaseDate };
        setHistory([...history, newHistoryEntry]);
        setNewDisease('');
        setDiseaseDate('');
    };

    return (
        <Container>
            <Row className="my-4">
                <Col>
                    <h2>Gestion des Patients</h2>
                    <Card>
                        <Card.Body>
                            <Form>
                                <Form.Group controlId="formPatientName">
                                    <Form.Label>Nom du patient</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Nom du patient" 
                                        value={name} 
                                        onChange={(e) => setName(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formBirthdate" className="mt-3">
                                    <Form.Label>Date de naissance</Form.Label>
                                    <Form.Control 
                                        type="date" 
                                        value={birthdate} 
                                        onChange={(e) => setBirthdate(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formUsername" className="mt-3">
                                    <Form.Label>Nom d'utilisateur</Form.Label>  {/* Nouveau champ pour le nom d'utilisateur */}
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Nom d'utilisateur" 
                                        value={username} 
                                        onChange={(e) => setUsername(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formPassword" className="mt-3">
                                    <Form.Label>Mot de passe</Form.Label>  {/* Nouveau champ pour le mot de passe */}
                                    <Form.Control 
                                        type="password" 
                                        placeholder="Mot de passe" 
                                        value={password} 
                                        onChange={(e) => setPassword(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formDoctor" className="mt-3">
                                    <Form.Label>Médecin</Form.Label>
                                    <Form.Control 
                                        as="select" 
                                        value={doctorId} 
                                        onChange={(e) => setDoctorId(e.target.value)}
                                    >
                                        <option value="">Sélectionner un médecin</option>
                                        {doctors.map(doctor => (
                                            <option key={doctor._id} value={doctor._id}>
                                                {doctor.name} - {doctor.specialty}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>

                                <h3 className="mt-4">Historique des Maladies</h3>
                                <Table striped bordered hover className="mt-3">
                                    <thead>
                                        <tr>
                                            <th>Maladie</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {history.map((entry, index) => (
                                            <tr key={index}>
                                                <td>{entry.disease}</td>
                                                <td>{new Date(entry.date).toLocaleDateString()}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>

                                <Form.Group controlId="formNewDisease" className="mt-3">
                                    <Form.Label>Nouvelle maladie</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Nouvelle maladie" 
                                        value={newDisease} 
                                        onChange={(e) => setNewDisease(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formDiseaseDate" className="mt-3">
                                    <Form.Label>Date de la maladie</Form.Label>
                                    <Form.Control 
                                        type="date" 
                                        value={diseaseDate} 
                                        onChange={(e) => setDiseaseDate(e.target.value)} 
                                    />
                                </Form.Group>

                                <Button 
                                    variant="secondary" 
                                    className="mt-3"
                                    onClick={addDiseaseToHistory}
                                >
                                    Ajouter maladie à l'historique
                                </Button>

                                <Button 
                                    variant={editMode ? "warning" : "primary"} 
                                    className="mt-3 ms-2"
                                    onClick={editMode ? updatePatient : addPatient}
                                >
                                    {editMode ? 'Modifier' : 'Ajouter'}
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <ListGroup>
                                {patients.map(patient => (
                                    <ListGroup.Item key={patient._id} className="d-flex justify-content-between align-items-center">
                                        <div>
                                            {patient.name} - {new Date(patient.birthdate).toLocaleDateString()}
                                        </div>
                                        <div>
                                            <Button 
                                                variant="warning" 
                                                size="sm" 
                                                className="me-2" 
                                                onClick={() => editPatient(patient)}
                                            >
                                                Modifier
                                            </Button>
                                            <Button 
                                                variant="danger" 
                                                size="sm" 
                                                onClick={() => deletePatient(patient._id)}
                                            >
                                                Supprimer
                                            </Button>
                                        </div>
                                    </ListGroup.Item>
                                ))}
                            </ListGroup>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default PatientList;
