import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Card, ListGroup, Table } from 'react-bootstrap';

function PatientHistory() {
    const [patients, setPatients] = useState([]);
    const [filteredPatients, setFilteredPatients] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedPatient, setSelectedPatient] = useState(null);
    const [history, setHistory] = useState([]);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/patients/")
            .then(response => response.json())
            .then(data => {
                setPatients(data);
                setFilteredPatients(data);
            })
            .catch(error => console.error('Error:', error));
    }, []);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
        const filtered = patients.filter(patient => 
            patient.name.toLowerCase().includes(e.target.value.toLowerCase())
        );
        setFilteredPatients(filtered);
    };

    const fetchHistory = (patientId) => {
        fetch(`http://127.0.0.1:8000/patients/${patientId}`)
            .then(response => response.json())
            .then(data => {
                setSelectedPatient(data);
                setHistory(data.history || []);
            })
            .catch(error => console.error('Error:', error));
    };

    return (
        <Container>
            <Row className="my-4">
                <Col>
                    <h2>Historique des Patients</h2>
                    <Card>
                        <Card.Body>
                            <Form>
                                <Form.Group controlId="searchPatient">
                                    <Form.Label>Rechercher un patient par nom</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Entrez le nom du patient" 
                                        value={searchTerm}
                                        onChange={handleSearch}
                                    />
                                </Form.Group>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <ListGroup>
                                {filteredPatients.map(patient => (
                                    <ListGroup.Item key={patient._id} className="d-flex justify-content-between align-items-center">
                                        <div>
                                            {patient.name} - {new Date(patient.birthdate).toLocaleDateString()}
                                        </div>
                                        <Button 
                                            variant="primary" 
                                            size="sm" 
                                            onClick={() => fetchHistory(patient._id)}
                                        >
                                            Voir Historique
                                        </Button>
                                    </ListGroup.Item>
                                ))}
                            </ListGroup>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {selectedPatient && (
                <Row className="my-4">
                    <Col>
                        <Card>
                            <Card.Body>
                                <h3>Historique de {selectedPatient.name}</h3>
                                <Table striped bordered hover>
                                    <thead>
                                        <tr>
                                            <th>Maladie</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {history.map((entry, index) => (
                                            <tr key={index}>
                                                <td>{entry.disease}</td>
                                                <td>{new Date(entry.date).toLocaleDateString()}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            )}
        </Container>
    );
}

export default PatientHistory;
