import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Card, ListGroup } from 'react-bootstrap';

function DepartmentList() {
    const [departments, setDepartments] = useState([]);
    const [name, setName] = useState('');
    const [editMode, setEditMode] = useState(false);
    const [currentDepartment, setCurrentDepartment] = useState(null);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/departments/")
            .then(response => response.json())
            .then(data => setDepartments(data))
            .catch(error => console.error('Error:', error));
    }, []);

    const addDepartment = () => {
        fetch("http://127.0.0.1:8000/departments/", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name }),
        })
        .then(() => {
            setName('');
            refreshDepartments();
        })
        .catch(error => console.error('Error:', error));
    };

    const updateDepartment = () => {
        fetch(`http://127.0.0.1:8000/departments/${currentDepartment._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name }),
        })
        .then(() => {
            setName('');
            setEditMode(false);
            setCurrentDepartment(null);
            refreshDepartments();
        })
        .catch(error => console.error('Error:', error));
    };

    const deleteDepartment = (id) => {
        fetch(`http://127.0.0.1:8000/departments/${id}`, {
            method: 'DELETE',
        })
        .then(() => {
            refreshDepartments();
        })
        .catch(error => console.error('Error:', error));
    };

    const refreshDepartments = () => {
        fetch("http://127.0.0.1:8000/departments/")
            .then(response => response.json())
            .then(data => setDepartments(data))
            .catch(error => console.error('Error:', error));
    };

    const editDepartment = (department) => {
        setEditMode(true);
        setCurrentDepartment(department);
        setName(department.name);
    };

    return (
        <Container>
            <Row className="my-4">
                <Col>
                    <h2>Gestion des Départements</h2>
                    <Card>
                        <Card.Body>
                            <Form>
                                <Form.Group controlId="formDepartmentName">
                                    <Form.Label>Nom du département</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Nom du département" 
                                        value={name} 
                                        onChange={(e) => setName(e.target.value)} 
                                    />
                                </Form.Group>

                                <Button 
                                    variant={editMode ? "warning" : "primary"} 
                                    className="mt-3"
                                    onClick={editMode ? updateDepartment : addDepartment}
                                >
                                    {editMode ? 'Modifier' : 'Ajouter'}
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <ListGroup>
                                {departments.map(department => (
                                    <ListGroup.Item key={department._id} className="d-flex justify-content-between align-items-center">
                                        {department.name}
                                        <div>
                                            <Button 
                                                variant="warning" 
                                                size="sm" 
                                                className="me-2" 
                                                onClick={() => editDepartment(department)}
                                            >
                                                Modifier
                                            </Button>
                                            <Button 
                                                variant="danger" 
                                                size="sm" 
                                                onClick={() => deleteDepartment(department._id)}
                                            >
                                                Supprimer
                                            </Button>
                                        </div>
                                    </ListGroup.Item>
                                ))}
                            </ListGroup>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default DepartmentList;
