import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { FaSignInAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import './Home.css'; // Importer le fichier CSS

function Home() {
    const navigate = useNavigate();
    const isUserLoggedIn = !!localStorage.getItem('role'); // Vérifie si l'utilisateur est connecté

    const handleLoginRedirect = () => {
        navigate('/login');
    };

    return (
        <div className="home-background">
            <Container className="text-center d-flex justify-content-center align-items-center h-100">
                <Row>
                    <Col md={12}>
                        <Card className="shadow-lg p-4" style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
                            <Card.Body>
                                <Card.Title>
                                    <h2 className="display-4">Bienvenue sur le Système de Gestion des Hôpitaux</h2>
                                </Card.Title>
                                {!isUserLoggedIn && (
                                    <>
                                        <Card.Text className="mt-3">
                                            <p className="lead">Veuillez vous connecter pour accéder à vos fonctionnalités.</p>
                                        </Card.Text>
                                        <Button variant="primary" onClick={handleLoginRedirect} className="mt-3">
                                            <FaSignInAlt className="me-2" /> Se Connecter
                                        </Button>
                                    </>
                                )}
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default Home;
