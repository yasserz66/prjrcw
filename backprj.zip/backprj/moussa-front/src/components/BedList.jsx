import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Card, Table } from 'react-bootstrap';

function BedList() {
    const [beds, setBeds] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [patients, setPatients] = useState([]);
    const [number, setNumber] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const [patientId, setPatientId] = useState('');
    const [editMode, setEditMode] = useState(false);
    const [currentBed, setCurrentBed] = useState(null);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/beds/")
            .then(response => response.json())
            .then(data => setBeds(data))
            .catch(error => console.error('Error:', error));
        
        fetch("http://127.0.0.1:8000/departments/")
            .then(response => response.json())
            .then(data => setDepartments(data))
            .catch(error => console.error('Error:', error));

        fetch("http://127.0.0.1:8000/patients/")
            .then(response => response.json())
            .then(data => setPatients(data))
            .catch(error => console.error('Error:', error));
    }, []);

    const addBed = () => {
        fetch("http://127.0.0.1:8000/beds/", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ number, department_id: departmentId, patient_id: patientId }),
        })
        .then(() => {
            setNumber('');
            setDepartmentId('');
            setPatientId('');
            refreshBeds();
        })
        .catch(error => console.error('Error:', error));
    };

    const updateBed = () => {
        fetch(`http://127.0.0.1:8000/beds/${currentBed._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ number, department_id: departmentId, patient_id: patientId }),
        })
        .then(() => {
            setNumber('');
            setDepartmentId('');
            setPatientId('');
            setEditMode(false);
            setCurrentBed(null);
            refreshBeds();
        })
        .catch(error => console.error('Error:', error));
    };

    const deleteBed = (id) => {
        fetch(`http://127.0.0.1:8000/beds/${id}`, {
            method: 'DELETE',
        })
        .then(() => {
            refreshBeds();
        })
        .catch(error => console.error('Error:', error));
    };

    const refreshBeds = () => {
        fetch("http://127.0.0.1:8000/beds/")
            .then(response => response.json())
            .then(data => setBeds(data))
            .catch(error => console.error('Error:', error));
    };

    const editBed = (bed) => {
        setEditMode(true);
        setCurrentBed(bed);
        setNumber(bed.number);
        setDepartmentId(bed.department_id);
        setPatientId(bed.patient_id);
    };

    const availableBeds = beds.filter(bed => !bed.patient_id);

    return (
        <Container>
            <Row className="my-4">
                <Col>
                    <h2>Gestion des Lits</h2>
                    <Card>
                        <Card.Body>
                            <Form>
                                <Form.Group controlId="formBedNumber">
                                    <Form.Label>Numéro du lit</Form.Label>
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Numéro du lit" 
                                        value={number} 
                                        onChange={(e) => setNumber(e.target.value)} 
                                    />
                                </Form.Group>

                                <Form.Group controlId="formDepartment" className="mt-3">
                                    <Form.Label>Département</Form.Label>
                                    <Form.Control 
                                        as="select" 
                                        value={departmentId} 
                                        onChange={(e) => setDepartmentId(e.target.value)}
                                    >
                                        <option value="">Sélectionner un département</option>
                                        {departments.map(department => (
                                            <option key={department._id} value={department._id}>
                                                {department.name}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>

                                <Form.Group controlId="formPatient" className="mt-3">
                                    <Form.Label>Patient (optionnel)</Form.Label>
                                    <Form.Control 
                                        as="select" 
                                        value={patientId} 
                                        onChange={(e) => setPatientId(e.target.value)}
                                    >
                                        <option value="">Sélectionner un patient</option>
                                        {patients.map(patient => (
                                            <option key={patient._id} value={patient._id}>
                                                {patient.name}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </Form.Group>

                                <Button 
                                    variant={editMode ? "warning" : "primary"} 
                                    className="mt-3"
                                    onClick={editMode ? updateBed : addBed}
                                >
                                    {editMode ? 'Modifier' : 'Ajouter'}
                                </Button>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <h3>Lits Disponibles</h3>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>Numéro du Lit</th>
                                        <th>Département</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {availableBeds.map(bed => (
                                        <tr key={bed._id}>
                                            <td>{bed.number}</td>
                                            <td>{departments.find(d => d._id === bed.department_id)?.name}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <Card>
                        <Card.Body>
                            <h3>Tous les Lits</h3>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>Numéro du Lit</th>
                                        <th>Département</th>
                                        <th>Patient</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {beds.map(bed => (
                                        <tr key={bed._id}>
                                            <td>{bed.number}</td>
                                            <td>{departments.find(d => d._id === bed.department_id)?.name}</td>
                                            <td>{bed.patient_id ? patients.find(p => p._id === bed.patient_id)?.name : 'Non attribué'}</td>
                                            <td>
                                                <Button 
                                                    variant="warning" 
                                                    size="sm" 
                                                    className="me-2" 
                                                    onClick={() => editBed(bed)}
                                                >
                                                    Modifier
                                                </Button>
                                                <Button 
                                                    variant="danger" 
                                                    size="sm" 
                                                    onClick={() => deleteBed(bed._id)}
                                                >
                                                    Supprimer
                                                </Button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default BedList;
