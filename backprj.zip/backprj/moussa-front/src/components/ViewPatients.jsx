import React, { useState, useEffect } from 'react';
import { Card, Button, Form, Container, Row, Col, ListGroup } from 'react-bootstrap';

function ViewPatients() {
    const [patients, setPatients] = useState([]);
    const [selectedPatient, setSelectedPatient] = useState(null);
    const [history, setHistory] = useState([]);
    const [newDisease, setNewDisease] = useState('');
    const [diseaseDate, setDiseaseDate] = useState('');

    useEffect(() => {
        fetch("http://127.0.0.1:8000/patients/")
            .then(response => response.json())
            .then(data => setPatients(data))
            .catch(error => console.error('Error:', error));
    }, []);

    const fetchHistory = (patientId) => {
        fetch(`http://127.0.0.1:8000/patients/${patientId}`)
            .then(response => response.json())
            .then(data => {
                setSelectedPatient(data);
                setHistory(data.history || []);
            })
            .catch(error => console.error('Error:', error));
    };

    const addDiseaseToHistory = () => {
        fetch(`http://127.0.0.1:8000/patients/${selectedPatient._id}/history`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ disease: newDisease, date: diseaseDate }),
        })
        .then(() => {
            setHistory([...history, { disease: newDisease, date: diseaseDate }]);
            setNewDisease('');
            setDiseaseDate('');
        })
        .catch(error => console.error('Error:', error));
    };

    return (
        <Container className="mt-4">
            <Row>
                <Col md={6}>
                    <h2 className="mb-4">Liste des Patients</h2>
                    <ListGroup>
                        {patients.map(patient => (
                            <ListGroup.Item key={patient._id}>
                                {patient.name} - {new Date(patient.birthdate).toLocaleDateString()}
                                <Button 
                                    variant="info" 
                                    className="float-end"
                                    onClick={() => fetchHistory(patient._id)}
                                >
                                    Voir Historique
                                </Button>
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                </Col>
                <Col md={6}>
                    {selectedPatient && (
                        <Card className="mt-4">
                            <Card.Body>
                                <Card.Title>Historique de {selectedPatient.name}</Card.Title>
                                <ListGroup className="mb-3">
                                    {history.map((entry, index) => (
                                        <ListGroup.Item key={index}>
                                            {entry.disease} - {new Date(entry.date).toLocaleDateString()}
                                        </ListGroup.Item>
                                    ))}
                                </ListGroup>
                                <Form>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Nouvelle maladie</Form.Label>
                                        <Form.Control 
                                            type="text" 
                                            placeholder="Entrez la maladie" 
                                            value={newDisease} 
                                            onChange={(e) => setNewDisease(e.target.value)} 
                                        />
                                    </Form.Group>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Date de la maladie</Form.Label>
                                        <Form.Control 
                                            type="date" 
                                            value={diseaseDate} 
                                            onChange={(e) => setDiseaseDate(e.target.value)} 
                                        />
                                    </Form.Group>
                                    <Button 
                                        variant="primary" 
                                        onClick={addDiseaseToHistory}
                                    >
                                        Ajouter à l'historique
                                    </Button>
                                </Form>
                            </Card.Body>
                        </Card>
                    )}
                </Col>
            </Row>
        </Container>
    );
}

export default ViewPatients;
