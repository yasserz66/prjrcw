// src/components/Chatbot.js
import React from 'react';

function Chatbot() {
  return (
    <div style={{ height: '90vh', width: '100%' }}>
      <iframe
        src="http://localhost:8501"
        title="Chatbot"
        style={{ height: '100%', width: '100%', border: 'none' }}
      />
    </div>
  );
}

export default Chatbot;
