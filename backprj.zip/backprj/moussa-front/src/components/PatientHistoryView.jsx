import React, { useState, useEffect } from 'react';
import { Container, Card, Button, ListGroup, Form, Row, Col } from 'react-bootstrap';

function PatientHistoryView() {
    const [history, setHistory] = useState([]);
    const [newDisease, setNewDisease] = useState('');
    const [diseaseDate, setDiseaseDate] = useState('');

    useEffect(() => {
        const userId = localStorage.getItem('userId');
        fetch(`http://127.0.0.1:8000/patients/${userId}`)
            .then(response => response.json())
            .then(data => setHistory(data.history || []))
            .catch(error => console.error('Error:', error));
    }, []);

    const addDiseaseToHistory = () => {
        const userId = localStorage.getItem('userId');
        fetch(`http://127.0.0.1:8000/patients/${userId}/history`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ disease: newDisease, date: diseaseDate }),
        })
        .then(() => {
            setHistory([...history, { disease: newDisease, date: diseaseDate }]);
            setNewDisease('');
            setDiseaseDate('');
        })
        .catch(error => console.error('Error:', error));
    };

    return (
        <Container className="mt-4">
            <h2 className="mb-4">Mon Historique Médical</h2>
            <Card>
                <Card.Body>
                    <ListGroup variant="flush">
                        {history.map((entry, index) => (
                            <ListGroup.Item key={index}>
                                <strong>Maladie:</strong> {entry.disease} <br />
                                <strong>Date:</strong> {new Date(entry.date).toLocaleDateString()}
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                </Card.Body>
            </Card>

            <Card className="mt-4">
                <Card.Body>
                    <Form>
                        <Row className="mb-3">
                            <Col>
                                <Form.Group controlId="formDiseaseName">
                                    <Form.Label>Nouvelle Maladie</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Entrez le nom de la maladie"
                                        value={newDisease}
                                        onChange={(e) => setNewDisease(e.target.value)}
                                    />
                                </Form.Group>
                            </Col>
                            <Col>
                                <Form.Group controlId="formDiseaseDate">
                                    <Form.Label>Date de la Maladie</Form.Label>
                                    <Form.Control
                                        type="date"
                                        value={diseaseDate}
                                        onChange={(e) => setDiseaseDate(e.target.value)}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Button variant="primary" onClick={addDiseaseToHistory}>
                            Ajouter à l'historique
                        </Button>
                    </Form>
                </Card.Body>
            </Card>
        </Container>
    );
}

export default PatientHistoryView;
