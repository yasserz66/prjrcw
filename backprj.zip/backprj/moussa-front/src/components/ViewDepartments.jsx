import React, { useState, useEffect } from 'react';
import { Container, Card, ListGroup } from 'react-bootstrap';

function ViewDepartments() {
    const [departments, setDepartments] = useState([]);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/departments/")
            .then(response => response.json())
            .then(data => setDepartments(data))
            .catch(error => console.error('Error:', error));
    }, []);

    return (
        <Container className="mt-4">
            <h2 className="mb-4">Liste des Départements</h2>
            <ListGroup>
                {departments.map(department => (
                    <ListGroup.Item key={department._id} className="mb-3">
                        <Card>
                            <Card.Body>
                                <Card.Title>{department.name}</Card.Title>
                            </Card.Body>
                        </Card>
                    </ListGroup.Item>
                ))}
            </ListGroup>
        </Container>
    );
}

export default ViewDepartments;
