import React, { useState, useEffect } from 'react';
import { Container, Card, Button, ListGroup, Modal, Form } from 'react-bootstrap';

function DoctorAppointmentsView() {
    const [appointments, setAppointments] = useState([]);
    const [selectedAppointment, setSelectedAppointment] = useState(null);
    const [appointmentDate, setAppointmentDate] = useState('');
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        const doctorId = localStorage.getItem('userId');
        fetch(`http://127.0.0.1:8000/appointments/doctor/${doctorId}`)
            .then(response => response.json())
            .then(data => setAppointments(data))
            .catch(error => console.error('Error:', error));
    }, []);

    const updateAppointment = () => {
        fetch(`http://127.0.0.1:8000/appointments/${selectedAppointment._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ appointment_date: appointmentDate }),
        })
        .then(() => {
            setAppointmentDate('');
            setSelectedAppointment(null);
            setShowModal(false);
            refreshAppointments();
        })
        .catch(error => console.error('Error:', error));
    };

    const deleteAppointment = (id) => {
        fetch(`http://127.0.0.1:8000/appointments/${id}`, {
            method: 'DELETE',
        })
        .then(() => {
            refreshAppointments();
        })
        .catch(error => console.error('Error:', error));
    };

    const refreshAppointments = () => {
        const doctorId = localStorage.getItem('userId');
        fetch(`http://127.0.0.1:8000/appointments/doctor/${doctorId}`)
            .then(response => response.json())
            .then(data => setAppointments(data))
            .catch(error => console.error('Error:', error));
    };

    const editAppointment = (appointment) => {
        setSelectedAppointment(appointment);
        setAppointmentDate(new Date(appointment.appointment_date).toISOString().split('T')[0]);
        setShowModal(true);
    };

    return (
        <Container className="mt-4">
            <h2 className="mb-4">Mes Rendez-vous</h2>
            <ListGroup>
                {appointments.map(appointment => (
                    <ListGroup.Item key={appointment._id} className="mb-3">
                        <Card>
                            <Card.Body>
                                <Card.Title>Patient: {appointment.patient_name}</Card.Title>
                                <Card.Text>
                                    Date du rendez-vous: {new Date(appointment.appointment_date).toLocaleDateString()}
                                </Card.Text>
                                <Button variant="warning" className="me-2" onClick={() => editAppointment(appointment)}>
                                    Modifier
                                </Button>
                                <Button variant="danger" onClick={() => deleteAppointment(appointment._id)}>
                                    Supprimer
                                </Button>
                            </Card.Body>
                        </Card>
                    </ListGroup.Item>
                ))}
            </ListGroup>

            {/* Modal pour la modification des rendez-vous */}
            <Modal show={showModal} onHide={() => setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Modifier Rendez-vous</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group controlId="formAppointmentDate">
                            <Form.Label>Date du rendez-vous</Form.Label>
                            <Form.Control
                                type="date"
                                value={appointmentDate}
                                onChange={(e) => setAppointmentDate(e.target.value)}
                            />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowModal(false)}>
                        Annuler
                    </Button>
                    <Button variant="primary" onClick={updateAppointment}>
                        Enregistrer les modifications
                    </Button>
                </Modal.Footer>
            </Modal>
        </Container>
    );
}

export default DoctorAppointmentsView;
