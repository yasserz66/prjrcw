import React, { useState, useEffect } from 'react';
import { Route, Routes, NavLink, useNavigate } from 'react-router-dom';
import { Navbar, Nav, Container, Button } from 'react-bootstrap';
import { FaHome, FaSignInAlt, FaHospital, FaUserMd, FaUserInjured, FaBed, FaHistory, FaCalendarAlt, FaMicroscope } from 'react-icons/fa';
import Home from './components/Home';
import Login from './components/Login';

import DepartmentList from './components/DepartmentList';
import DoctorList from './components/DoctorList';
import PatientList from './components/PatientList';
import BedList from './components/BedList';
import PatientHistory from './components/PatientHistory';
import Appointment from './components/Appointment';

import PatientAppointments from './components/PatientAppointments';
import PatientHistoryView from './components/PatientHistoryView';
import ViewDoctors from './components/ViewDoctors';

import ViewDepartments from './components/ViewDepartments';
import DoctorAppointmentsView from './components/DoctorAppointmentsView';
import ViewPatients from './components/ViewPatients';
import Chatbot from './components/Chatbot'; // Make sure this import is correct
function App() {
  const [role, setRole] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userRole = localStorage.getItem('role');
    setRole(userRole);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('role');
    localStorage.removeItem('userId');
    setRole(null);
    navigate('/login');
  };

  const renderNavLinks = () => {
    if (!role) {
      return (
        <>
          <Nav.Link as={NavLink} to="/">
            <FaHome className="me-2" /> Home
          </Nav.Link>
          <Nav.Link as={NavLink} to="/login">
            <FaSignInAlt className="me-2" /> Se Connecter
          </Nav.Link>
        </>
      );
    }

    if (role === 'admin') {
      return (
        <>
          <Nav.Link as={NavLink} to="/departments">
            <FaHospital className="me-2" /> Départements
          </Nav.Link>
          <Nav.Link as={NavLink} to="/doctors">
            <FaUserMd className="me-2" /> Médecins
          </Nav.Link>
          <Nav.Link as={NavLink} to="/patients">
            <FaUserInjured className="me-2" /> Patients
          </Nav.Link>
          <Nav.Link as={NavLink} to="/beds">
            <FaBed className="me-2" /> Lits
          </Nav.Link>
          <Nav.Link as={NavLink} to="/history">
            <FaHistory className="me-2" /> Historique des Patients
          </Nav.Link>
          <Nav.Link as={NavLink} to="/appointment">
            <FaCalendarAlt className="me-2" /> Prendre un Rendez-vous
          </Nav.Link>
          <Nav.Link as={NavLink} to="/chatbot">
            <FaMicroscope className="me-2" /> Chatbot
          </Nav.Link>
        </>
      );
    } else if (role === 'doctor') {
      return (
        <>
          <Nav.Link as={NavLink} to="/view-departments">
            <FaHospital className="me-2" /> Départements
          </Nav.Link>
          <Nav.Link as={NavLink} to="/view-patients">
            <FaUserInjured className="me-2" /> Patients
          </Nav.Link>
          <Nav.Link as={NavLink} to="/history">
            <FaHistory className="me-2" /> Historique des Patients
          </Nav.Link>
          <Nav.Link as={NavLink} to="/appointment">
            <FaCalendarAlt className="me-2" /> Rendez-vous
          </Nav.Link>
        </>
      );
    } else if (role === 'patient') {
      return (
        <>
          <Nav.Link as={NavLink} to="/my-appointments">
            <FaCalendarAlt className="me-2" /> Mes Rendez-vous
          </Nav.Link>
          <Nav.Link as={NavLink} to="/my-history">
            <FaHistory className="me-2" /> Mon Historique
          </Nav.Link>
          <Nav.Link as={NavLink} to="/view-doctors">
            <FaUserMd className="me-2" /> Voir les Médecins
          </Nav.Link>
          {/* New Chatbot Link */}
          <Nav.Link as={NavLink} to="/Chatbot"> {/* Link to the Chatbot */}
            <FaMicroscope className="me-2" /> Chatbot
          </Nav.Link>
        </>
      );
    }

    return null;
  };

  return (
    <div className="App">
      <Navbar bg="primary" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="/">Gestion des Hôpitaux</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              {renderNavLinks()}
            </Nav>
            {role && (
              <Button variant="outline-light" onClick={handleLogout}>
                Se Déconnecter
              </Button>
            )}
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Container className="mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />

          {/* Routes pour l'administrateur */}
          {role === 'admin' && (
            <>
              <Route path="/departments" element={<DepartmentList />} />
              <Route path="/doctors" element={<DoctorList />} />
              <Route path="/patients" element={<PatientList />} />
              <Route path="/beds" element={<BedList />} />
              <Route path="/history" element={<PatientHistory />} />
              <Route path="/appointment" element={<Appointment />} />
            </>
          )}

          {/* Routes pour le médecin */}
          {role === 'doctor' && (
            <>
              <Route path="/view-departments" element={<ViewDepartments />} />
              <Route path="/view-patients" element={<ViewPatients />} />
              <Route path="/history" element={<PatientHistory />} />
              <Route path="/appointment" element={<DoctorAppointmentsView />} />
            </>
          )}

          {/* Routes pour le patient */}
          {role === 'patient' && (
            <>
              <Route path="/my-appointments" element={<PatientAppointments />} />
              <Route path="/my-history" element={<PatientHistoryView />} />
              <Route path="/view-doctors" element={<ViewDoctors />} />
              <Route path="/chatbot" element={<Chatbot />} /> {/* Add Chatbot route here */}

            </>
          )}
        </Routes>
      </Container>
    </div>
  );
}

export default App;
