from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pymongo import MongoClient
from bson import ObjectId
from typing import List
from datetime import datetime
import bcrypt

# Connexion à MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client.hospital_management

app = FastAPI()

# Configuration CORS pour permettre les requêtes depuis React
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permettre à toutes les origines d'accéder à l'API
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modèles pour les différentes entités
class Department(BaseModel):
    name: str

class Doctor(BaseModel):
    name: str
    specialty: str
    department_id: str
    username: str
    password: str

class DiseaseHistory(BaseModel):
    disease: str
    date: str  # Vous pouvez utiliser datetime à la place de str pour une meilleure gestion

class Patient(BaseModel):
    name: str
    birthdate: str
    history: List[DiseaseHistory] = []
    doctor_id: str
    username: str
    password: str

class Bed(BaseModel):
    number: int
    department_id: str
    patient_id: str = None

class Appointment(BaseModel):
    patient_id: str
    doctor_id: str
    appointment_date: datetime

class UserLogin(BaseModel):
    username: str
    password: str

# Helper pour convertir ObjectId en str
def to_str_id(document):
    document["_id"] = str(document["_id"])
    return document

# Routes pour la gestion des utilisateurs
@app.post("/login")
def login(user: UserLogin):
    if user.username == "admin" and user.password == "admin":
        return {"role": "admin", "userId": "admin"}

    user_record = db.patients.find_one({"username": user.username})
    if user_record and bcrypt.checkpw(user.password.encode('utf-8'), user_record["password"].encode('utf-8')):
        return {"role": "patient", "userId": str(user_record["_id"])}

    user_record = db.doctors.find_one({"username": user.username})
    if user_record and bcrypt.checkpw(user.password.encode('utf-8'), user_record["password"].encode('utf-8')):
        return {"role": "doctor", "userId": str(user_record["_id"])}

    raise HTTPException(status_code=401, detail="Invalid username or password")

# Routes pour la gestion des départements
@app.post("/departments/")
def create_department(department: Department):
    department_id = db.departments.insert_one(department.dict()).inserted_id
    return {"id": str(department_id)}

@app.get("/departments/")
def get_departments():
    departments = list(db.departments.find())
    return [to_str_id(department) for department in departments]

@app.put("/departments/{department_id}")
def update_department(department_id: str, department: Department):
    result = db.departments.update_one({"_id": ObjectId(department_id)}, {"$set": department.dict()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Department not found")
    return {"message": "Department updated"}

@app.delete("/departments/{department_id}")
def delete_department(department_id: str):
    result = db.departments.delete_one({"_id": ObjectId(department_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Department not found")
    return {"message": "Department deleted"}

@app.get("/departments/{department_id}")
def get_department(department_id: str):
    department = db.departments.find_one({"_id": ObjectId(department_id)})
    if not department:
        raise HTTPException(status_code=404, detail="Department not found")
    return to_str_id(department)

# Ajout et modification des médecins avec hachage de mot de passe
@app.post("/doctors/")
def create_doctor(doctor: Doctor):
    department = db.departments.find_one({"_id": ObjectId(doctor.department_id)})
    if not department:
        raise HTTPException(status_code=404, detail="Department not found")
    
    # Hachage du mot de passe
    hashed_password = bcrypt.hashpw(doctor.password.encode('utf-8'), bcrypt.gensalt())
    doctor.password = hashed_password.decode('utf-8')

    doctor_id = db.doctors.insert_one(doctor.dict()).inserted_id
    return {"id": str(doctor_id)}

@app.get("/doctors/")
def get_doctors():
    doctors = list(db.doctors.find())
    return [to_str_id(doctor) for doctor in doctors]

@app.put("/doctors/{doctor_id}")
def update_doctor(doctor_id: str, doctor: Doctor):
    department = db.departments.find_one({"_id": ObjectId(doctor.department_id)})
    if not department:
        raise HTTPException(status_code=404, detail="Department not found")

    # Hachage du mot de passe s'il est modifié
    if doctor.password:
        hashed_password = bcrypt.hashpw(doctor.password.encode('utf-8'), bcrypt.gensalt())
        doctor.password = hashed_password.decode('utf-8')

    result = db.doctors.update_one({"_id": ObjectId(doctor_id)}, {"$set": doctor.dict()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Doctor not found")
    return {"message": "Doctor updated"}

# Ajout et modification des patients avec hachage de mot de passe
@app.post("/patients/")
def create_patient(patient: Patient):
    doctor = db.doctors.find_one({"_id": ObjectId(patient.doctor_id)})
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")
    
    # Hachage du mot de passe
    hashed_password = bcrypt.hashpw(patient.password.encode('utf-8'), bcrypt.gensalt())
    patient.password = hashed_password.decode('utf-8')

    patient_id = db.patients.insert_one(patient.dict()).inserted_id
    return {"id": str(patient_id)}

@app.get("/patients/")
def get_patients():
    patients = list(db.patients.find())
    return [to_str_id(patient) for patient in patients]

@app.put("/patients/{patient_id}")
def update_patient(patient_id: str, patient: Patient):
    doctor = db.doctors.find_one({"_id": ObjectId(patient.doctor_id)})
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")

    # Hachage du mot de passe s'il est modifié
    if patient.password:
        hashed_password = bcrypt.hashpw(patient.password.encode('utf-8'), bcrypt.gensalt())
        patient.password = hashed_password.decode('utf-8')

    result = db.patients.update_one({"_id": ObjectId(patient_id)}, {"$set": patient.dict()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Patient not found")
    return {"message": "Patient updated"}

@app.delete("/patients/{patient_id}")
def delete_patient(patient_id: str):
    result = db.patients.delete_one({"_id": ObjectId(patient_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Patient not found")
    return {"message": "Patient deleted"}

@app.get("/patients/{patient_id}")
def get_patient(patient_id: str):
    patient = db.patients.find_one({"_id": ObjectId(patient_id)})
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return to_str_id(patient)

# Ajout d'une nouvelle maladie à l'historique d'un patient
@app.post("/patients/{patient_id}/history")
def add_disease_to_history(patient_id: str, disease_history: DiseaseHistory):
    result = db.patients.update_one(
        {"_id": ObjectId(patient_id)},
        {"$push": {"history": disease_history.dict()}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Patient not found")
    return {"message": "Disease added to history"}

# Routes pour la gestion des lits
@app.post("/beds/")
def create_bed(bed: Bed):
    department = db.departments.find_one({"_id": ObjectId(bed.department_id)})
    if not department:
        raise HTTPException(status_code=404, detail="Department not found")
    
    if bed.patient_id:
        patient = db.patients.find_one({"_id": ObjectId(bed.patient_id)})
        if not patient:
            raise HTTPException(status_code=404, detail="Patient not found")

    bed_id = db.beds.insert_one(bed.dict()).inserted_id
    return {"id": str(bed_id)}

@app.get("/beds/")
def get_beds():
    beds = list(db.beds.find())
    return [to_str_id(bed) for bed in beds]

@app.put("/beds/{bed_id}")
def update_bed(bed_id: str, bed: Bed):
    department = db.departments.find_one({"_id": ObjectId(bed.department_id)})
    if not department:
        raise HTTPException(status_code=404, detail="Department not found")
    
    if bed.patient_id:
        patient = db.patients.find_one({"_id": ObjectId(bed.patient_id)})
        if not patient:
            raise HTTPException(status_code=404, detail="Patient not found")

    result = db.beds.update_one({"_id": ObjectId(bed_id)}, {"$set": bed.dict()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Bed not found")
    return {"message": "Bed updated"}

@app.delete("/beds/{bed_id}")
def delete_bed(bed_id: str):
    result = db.beds.delete_one({"_id": ObjectId(bed_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Bed not found")
    return {"message": "Bed deleted"}

@app.get("/beds/{bed_id}")
def get_bed(bed_id: str):
    bed = db.beds.find_one({"_id": ObjectId(bed_id)})
    if not bed:
        raise HTTPException(status_code=404, detail="Bed not found")
    return to_str_id(bed)

# Routes pour la gestion des rendez-vous
@app.post("/appointments/")
def create_appointment(appointment: Appointment):
    patient = db.patients.find_one({"_id": ObjectId(appointment.patient_id)})
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    doctor = db.doctors.find_one({"_id": ObjectId(appointment.doctor_id)})
    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found")
    
    appointment_id = db.appointments.insert_one(appointment.dict()).inserted_id
    return {"id": str(appointment_id)}

@app.get("/appointments/doctor/{doctor_id}")
def get_appointments_by_doctor(doctor_id: str):
    appointments = list(db.appointments.find({"doctor_id": doctor_id}))
    detailed_appointments = []
    for appointment in appointments:
        patient = db.patients.find_one({"_id": ObjectId(appointment["patient_id"])})
        if patient:
            appointment["patient_name"] = patient["name"]
        detailed_appointments.append(appointment)
    return [to_str_id(appointment) for appointment in detailed_appointments]


@app.get("/appointments/")
def get_appointments():
    appointments = list(db.appointments.find())
    return [to_str_id(appointment) for appointment in appointments]

@app.get("/appointments/{patient_id}")
def get_appointments_by_patient(patient_id: str):
    appointments = list(db.appointments.find({"patient_id": patient_id}))
    return [to_str_id(appointment) for appointment in appointments]

@app.put("/appointments/{appointment_id}")
def update_appointment(appointment_id: str, appointment: Appointment):
    result = db.appointments.update_one(
        {"_id": ObjectId(appointment_id)},
        {"$set": appointment.dict()}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Appointment not found")
    return {"message": "Appointment updated"}

@app.delete("/appointments/{appointment_id}")
def delete_appointment(appointment_id: str):
    result = db.appointments.delete_one({"_id": ObjectId(appointment_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Appointment not found")
    return {"message": "Appointment deleted"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
